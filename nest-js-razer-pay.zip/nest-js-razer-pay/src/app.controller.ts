//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Dependency
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import { Controller, Get, Post, Req, Res, HttpCode, Body, UsePipes, ValidationPipe, UseInterceptors, Query, Param } from '@nestjs/common';
import { FileFieldsInterceptor, FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { Response } from 'express';
import { createHmac } from 'node:crypto';
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
const Razorpay = require('razorpay');
const { validatePaymentVerification, validateWebhookSignature } = require('../node_modules/razorpay/dist/utils/razorpay-utils');
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//Service
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
import { AppService } from './app.service';
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
@Controller()
export class AppController {
  constructor(private readonly appService: AppService) { }

  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  //Make Payment
  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  @Post('make-payment')
  async createPayment(@Req() req: any, @Res() res: any): Promise<any> {
    //+++++++++++++++++++++++++++++++++++++++++++++++++++
    //Declartion
    //+++++++++++++++++++++++++++++++++++++++++++++++++++
    let resData: any = {
      status: false,
      d: {},
      message: ''
    }
    try {
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      //GENERATE Razer ORDER ID
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      const razerPayOrderID = 'New-order';
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      //Total Amount
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      let mainAmount = 500;
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      var options = {
        amount: mainAmount,
        currency: "INR",
        receipt: razerPayOrderID
      };
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      const razerInstance = new Razorpay({ key_id:  process.env.RAZER_PAY_ID, key_secret:  process.env.RAZER_PAY_SECRET});
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      //Create Razer Order
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      razerInstance.orders.create(options, async function (err: any, razerOBJ: any) {
        if (err) {
          resData.status = false;
          resData.message = JSON.stringify(err);
          return res.status(200).json(resData);
        } else {
          //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
          //console.log(razerOBJ);
          //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
          //let getResond = await this.appService.paymentInitOperation(razerOBJ);
          //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
          resData.status = true;
          resData.d.order = razerOBJ.id;
          resData.d.razerpayObjset = razerOBJ;
          //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
          return res.status(200).json(resData);
        }
      });
    } catch (e) {
      //+++++++++++++++++++++++++++++++++++++++++
      console.log(e);
      //+++++++++++++++++++++++++++++++++++++++++
      resData.d = e;
      resData.status = false;
      resData.message = 'error!!';
      res.status(601).json(resData);
    }
  }
  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  //Confirm Paymnet
  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  @Post('confirm-payment')
  async confirmPayment(@Req() req: any, @Res() res: any): Promise<any> {
    //+++++++++++++++++++++++++++++++++++++++++++++++++++
    //Declartion
    //+++++++++++++++++++++++++++++++++++++++++++++++++++
    let resData: any = {
      status: false,
      d: {},
      message: ''
    }
    let isValid:Boolean =  false;
    //+++++++++++++++++++++++++++++++++++++++++++++++++++
    let order_uuid: any = req.body.order_uuid;
    let razorpay_order_id: any = req.body.razorpay_order_id;
    let razorpay_signature: any = req.body.razorpay_signature;
    let razorpay_payment_id: any = req.body.razorpay_payment_id;
    //+++++++++++++++++++++++++++++++++++++++++++++++++++
    if (!order_uuid) {
      resData.message = 'bad request';
      return res.status(200).json(resData);
    }
    if (!razorpay_order_id) {
      resData.message = 'bad request';
      return res.status(200).json(resData);
    }
    if (!razorpay_signature) {
      resData.message = 'bad request';
      return res.status(200).json(resData);
    }
    if (!razorpay_payment_id) {
      resData.message = 'bad request';
      return res.status(200).json(resData);
    }
    try {
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++
      //First Process
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++
      isValid = validatePaymentVerification({
        "order_id": razorpay_order_id, "payment_id": razorpay_payment_id
      }, razorpay_signature, process.env.RAZER_PAY_SECRET);
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++
      //2nd Process
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++
      const hashData = createHmac('sha256', process.env.RAZER_PAY_SECRET)
      .update(razorpay_order_id + "|" + razorpay_payment_id)
      .digest('hex');
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++
      if (razorpay_signature == hashData) {
        isValid = true;
      }
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      //Payment Confirmation
      //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      if (isValid) {
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        //let getResond = await this.appService.paymentSucessOperation();
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        return res.status(200).json(resData);
      } else {
         //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
         //let getResond = await this.appService.paymentFailOperation();
         //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
         return res.status(200).json(resData);
      }
    } catch (e) {
      //+++++++++++++++++++++++++++++++++++++++++
      console.log(e);
      //+++++++++++++++++++++++++++++++++++++++++
      resData.d = e;
      resData.status = false;
      resData.message = 'error!!';
      res.status(601).json(resData);
    }
  }
}

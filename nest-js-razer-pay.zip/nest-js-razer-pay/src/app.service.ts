import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  paymentInitOperation(razerOBJ: any): string {
    let resData: any = {
      status: false,
      d: {},
      message: ''
    }
    //+++++++++++++++++++++++++++++++++++++++++
    //DB OPERTAION 
    //+++++++++++++++++++++++++++++++++++++++++
    resData.d.orderID = razerOBJ.id;
    //+++++++++++++++++++++++++++++++++++++++++
    resData.status = true;
    resData.message = 'payment init';
    return resData;
  }
  paymentSucessOperation(): string {
    return 'Sucess'; // DB Operation Will Be going In
  }
  paymentFailOperation(): string {
    return 'Fail'; // DB Operation Will Be going In
  }
}
